package com.citi.idm.cms.htmlsign;
/*
*
* A free Java sample program 
* to POST to a HTTPS secure SSL website
*
* @author William Alexander
* free for use as long as this comment is included 
* in the program as it is
* 
* More Free Java programs available for download 
* at http://www.java-samples.com
*
*/
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.security.cert.X509Certificate;

public class SSLPost 
{
      public static void doPost(byte[] signedData,X509Certificate aCertificate,String postURL,String origData)
      {
		try { 
			System.out.println("URL is"+postURL);
			System.out.println("signedData = "+signedData);
			System.out.println("aCertificate = "+aCertificate.getEncoded().toString());
			
			HtmlSigningDTO signingDTO = new HtmlSigningDTO();
			
			signingDTO.setOriginalData(origData);
			signingDTO.setACertificate(aCertificate);
			signingDTO.setSignedData(signedData);

			//String query = "SignedData=" + signedData.toString()+"&CertiFicate=" + aCertificate.getEncoded().toString(); 
			
			URL testServlet = new URL( postURL );
			HttpURLConnection connection = (HttpURLConnection)testServlet.openConnection() ;
			
			System.out.println("connection"+connection);

			//HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
			connection.setDoInput(true); 
			connection.setDoOutput(true);
			connection.setRequestMethod("POST"); 
			//connection.setRequestProperty("Content-length",String.valueOf (query.length())); 
			connection.setRequestProperty("Content-Type","application/octet-stream"); 
			connection.setRequestProperty("User-Agent", "Mozilla/4.0 (compatible; MSIE 5.0; Windows 98; DigExt)"); 

			ObjectOutputStream os = new ObjectOutputStream(connection.getOutputStream());
			os.writeObject(signingDTO);
			
			os.flush();
			os.close();
			System.out.println("Resp Code:"+connection.getResponseCode()); 
			System.out.println("Resp Message:"+ connection.getResponseMessage()); 
		}
		catch(Exception e) 
		{ 
			System.out.println( "Something bad just happened." ); 
			System.out.println( e ); 
			e.printStackTrace(); 
		}
      }

}