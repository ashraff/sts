/***************************************************************
*
*   The use, disclosure, reproduction, modification, transfer,
*   or transmittal of this work for any purpose in any form or
*   by any means without the written permission of Citibank, N.A.
*   is strictly prohibited.
*
*	Author : Ashraff Ali wahab
*   Copyright (c) 2007 Citibank, N.A.
*   All rights reserved
*
*******************************************************************/
package com.citi.idm.cms.htmlsign;

import java.util.Vector;

public class IDMConstants
{
	
	public static final String RESOURCE_BUNLDE_NAME		= "com.citibank.casa.idm";
	public static final String PACKAGE_NAME		= "com/citibank/casa/idm/";
	public static final String RESOURCE_MSG_PREFIX = "";//;ILanguageManager.MSG_PHRASE_NAME_PREFIX;
	public static final String RESOURCE_LBL_PREFIX ="";//;ILanguageManager.MSG_PHRASE_NAME_PREFIX;
	//PDF States
	public static final String NEW = "NEW";
	public static final String SIGNED = "SIGNED";
	public static final String DELETED = "DELETED";
	public static final String OLD = "OLD";
	
	//ACTIONS
	public static final String SUBMIT = "SUBMIT";
	public static final String VIEW = "VIEW";
	public static final String CANCEL = "CANCEL";
	
	public static final String INSERT_SQL = "INSERT INTO IDM_PDF_DATA (DOC_ID,PDF_STA_TYP,DATA_BLOB) values (?,?,EMPTY_BLOB())";
	public static final String SELECT_FOR_UPDATE_SQL = "SELECT DATA_BLOB FROM IDM_PDF_DATA WHERE DOC_ID=? AND PDF_STA_TYP=? FOR UPDATE";
	public static final String UPDATE_SQL = "UPDATE IDM_PDF_DATA SET DATA_BLOB = ?,PDF_STA_TYP=? WHERE DOC_ID=? AND PDF_STA_TYP=?  ";	
	public static final String SELECT_PDF = "SELECT DATA_BLOB FROM IDM_PDF_DATA where doc_id=? AND PDF_STA_TYP=? ";
	
	//DAL
	
	public static final String IDM_MAINT_DAL = "IDM_PDF_DATA_MNT";
	public static final String IDM_QUERY_DAL = "IDM_PDF_DATA_QRY";
	
	public static final String DOC_ID = "DOC_ID";
	public static final String REF_DOC_ID = "REF_DOC_ID";
	public static final String PDF_STA_TYP = "PDF_STA_TYP"; 
	public static final String DATA_BLOB = "DATA_BLOB"; 
	public static final String HASH_VALUE = "HASH_VALUE";
	public static final String CREAT_TM = "CREAT_TM"; 
	public static final String TIMESTAMP = "TIMESTAMP";
	
	public static final String APP_ID = "APP_ID";
	public static final String CANCEL_URL = "CANCEL_URL";
	public static final String CONT_TYPE = "CONT_TYPE";
	public static final String CREAT_DT = "CREAT_DT";
	public static final String DN = "DN";
	public static final String DOC_FMT = "DOC_FMT";	
	public static final String DOC_NAM = "DOC_NAM";
	public static final String FST_NAM = "FST_NAM";
	public static final String HEADER_ID = "HEADER_ID";
	public static final String HEADER_NAM = "HEADER_NAM";
	public static final String IS_AUTH_SIGN = "IS_AUTH_SIGN";
	public static final String LABEL = "LABEL";
	public static final String LGL_DSR = "LGL_DSR";
	public static final String LGL_DSR_1 = "LGL_DSR_1";
	public static final String LGL_DSR_2 = "LGL_DSR_2";
	public static final String LGL_DSR_3 = "LGL_DSR_3";
	public static final String LST_NAM = "LST_NAM";
	public static final String NET_AMT = "NET_AMT";
	public static final String NO_OF_BATCHES = "NO_OF_BATCHES";
	public static final String PTY_ID = "PTY_ID";
	public static final String PTY_NAM = "PTY_NAM";
	public static final String SIGNATURE_FIELD = "SIGNATURE_FIELD";
	public static final String SUBMIT_URL = "SUBMIT_URL";
	public static final String X509_CERT = "X509_CERT";
	public static final String BENE_ACCT_NO = "BENE_ACCT_NO";
	public static final String BENE_ACCT_NAM = "BENE_ACCT_NAM";
	
	
	public static final String IS_PDF_SHOWN = "IS_PDF_SHOWN";
	public static final String IS_PDF_GEN_SUCCESS = "IS_PDF_GEN_SUCCESS";
	public static final String PDF_URL_STRING = "PDF_URL_STRING";
	public static final String X509_SN = "X509_SN";
	public static final String IS_PDF_RET_SUCCESS = "IS_PDF_RET_SUCCESS";
	public static final String IS_PDF_STORE_SUCCESS = "IS_PDF_STORE_SUCCESS";
	public static final String IS_HIGH_ASSURANCE_CLIENT = "IS_HIGH_ASSURANCE_CLIENT";
	public static final String BATCH = "BATCH";
	public static final String SUMMARY = "SUMMARY";
	public static final String DETAIL = "DETAIL";
	public static final String FILE = "FILE";
	public static final String BATCH_CREAT_DT = "BATCH_CREAT_DT";
	public static final String BATCH_ID = "BATCH_ID";
	public static final String CFDLY_IND = "CFDLY_IND";
	public static final String FILE_IMPORT_FILE_NAME = "FILE_IMPORT_FILE_NAME";	
	public static final String NO_OF_TXNS = "NO_OF_TXNS";
	public static final String PYMT_DETAIL_LIST = "PYMT_DETAIL_LIST";
	public static final String RUN_DT = "RUN_DT";
	public static final String STATUS = "STATUS";
	public static final String ALT_REAS = "ALT_REAS";
	
	public static final String VIEW_HISTORY_URL = "/CasaSSL/PDFHandlerServlet?ACTION=VIEW&STATUS=OLD&DOC_ID=";
	public static final String VIEW_PDF_URL = "/CasaSSL/PDFHandlerServlet?ACTION=VIEW&STATUS=NEW&DOC_ID=";
	public static final String SUBMIT_PDF_URL = "/CasaSSL/PDFSubmitServlet?ACTION=SUBMIT&STATUS=NEW&DOC_ID=";
	public static final String CANCEL_PDF_URL = "/CasaSSL/PDFSubmitServlet?ACTION=CANCEL&STATUS=NEW";
	public static final String CONNECTION_TYPE  = "https://";
	
	
	//ERROR
	public static final String DOC_LEN_ZERO_ERROR = "DOC_LEN_ZERO_ERROR";
	public static final String DB_ERROR = "DB_ERROR";
	public static final String EVAULT_STORE_ERROR = "EVAULT_STORE_ERROR";
	public static final String PDF_NOT_SUBMITTED_ERROR = "PDF_NOT_SUBMITTED_ERROR";
	public static final String IDM_RELEASE_ERROR_ID = RESOURCE_MSG_PREFIX + "IDM_RELEASE_ERROR";
	
	//Format
	public static final String PDF_FORMAT = "PDF";
	
	public static final String RELEASER_LABEL = "RELEASER_LABEL";
	public static final String COUNTERSIGN_LABEL = "COUNTERSIGN_LABEL";
	
	public static final String RELEASE = "RELEASE";
	
	// CFC Fields
	
	public static final String SUCCESS ="SUCCESS";
	public static final String SPDF = "Store PDF";
	public static final String GPDF = "Generate PDF";
	public static final String RPDF = "Retrieve PDF";
	
	public static final String APPLICATION_IDENTIFIER = "CN=CitiDirect for Cash and Trade, OU=GECD, O=Citi, C=US";
	public static final String CITIDIRECT_IDENTIFIER = "CN=CitiVaultDevPTECer, OU=Citigroup, O=Citigroup, C=US";
	public static final int CITIDIRECT_APP_PTY_ID = 35687;
	
	public static final String HTML_TYPE = "HTML";
	public static final String SIGNING_DOCUMENT_TYPE = "SIGNING_DOCUMENT_TYPE";
	public static final String detailHTMLFormat = "detail_html.xsl";
	public static final String summaryHTMLFormat = "summary_html.xsl";
	public static final String fileHTMLFormat = "file_html.xsl";
	public static final String batchHTMLFormat = "batch_html.xsl";
	public static final String HTML_TITLE = "HTML_TITLE";
	public static final String FORMAT_HTML = "FORMAT_HTML";
	public static final String FORMAT_XML = "FORMAT_XML";
	public static final String SIGNED_CFC = "SIGNED_CFC";
	public static final String PUBLIC_KEY = "PUBLIC_KEY";
	public static final String SIGNATURE = "SIGNATURE";
	public static final String COUNTER_SIGNATURE = "COUNTER_SIGNATURE";
	public static final String SIGNATURE_DATETIME = "SIGNATURE_DATETIME";
	public static final String COUNTER_SIGNATURE_DATETIME = "COUNTER_SIGNATURE_DATETIME";
	public static final String HTML_DATE_TIME_FORMAT = "yyyy.MM.dd HH:mm:ss Z";

	/**
	 * 
	 */
	public static Vector getDetailFields() {
		return detailFields;
	}

	public static Vector detailFields = new Vector();
	static {

		detailFields.addElement("ACCT_CCY_COD");
		detailFields.addElement("ACCT_NO");
		detailFields.addElement("PTY_NAM");
		detailFields.addElement("BENE_PTY_NAM");
		detailFields.addElement("ORD_PTY_NAM");
		detailFields.addElement("DOC_ID");
		detailFields.addElement("BENE_ACCT_NAM");
		detailFields.addElement("PYMT_TYP");
		detailFields.addElement("ISO_CCY_COD");
		detailFields.addElement("MT100_REF_NO");
		detailFields.addElement("TRAN_AMT");
		detailFields.addElement("TRAN_TYP");
		detailFields.addElement("TRAN_VAL_DT");
		detailFields.addElement("BENE_ACCT_NO");

	}
	
	//Detail XML Tags
	
	public static final String DETAIL_XML = "Detail";
	public static final String TITLE_XML = "TITLE";
	public static final String COLUMN_XML = "Column";
	public static final String LABEL_XML = "_LABEL";	
	public static final String DISCLAIMER1_XML = "Disclaimer1";
	public static final String DISCLAIMER2_XML = "Disclaimer2";
	public static final String DISCLAIMER3_XML = "Disclaimer3";
	public static final String APP_PTY_ID = "APP_PTY_ID";
	
	public static final String SIGNING_ALGORITHM = "SHA1withRSA";
	public static final String HTML_CONTENT_TYPE = "text/html";
}
 
