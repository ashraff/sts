package com.citi.idm.cms.htmlsign;

import java.io.*;
import java.util.zip.*;

/**
 This class provides a convenient way to compress/decompress a buffer.
*/
public class Compressor
{
	//these constants are the ones used in SessionConstants, if that is changed this has
	//to change too
	public static final String FLD_COMPRESSED_MSG = "_COMPRESSED_MSG_";
    public static final String FLD_COMPRESSED_UTF_MSG = "_COMPRESSED_UTF_MSG_";
    /**
     Compresses a buffer using the GZIP algorithm.
     @param inputBuf The buffer to compress
     @returns The compressed data as a byte array.
     */
    static public byte [] compress (byte[] inputBuf) throws IOException
    {
        return compress (inputBuf, inputBuf.length);
    }

    /**
     Compresses a buffer using the GZIP algorithm and returns a serialized CFC
     containing the compressed data
     @param inputBuf The buffer to compress
     @returns The compressed data as a byte array.
     */
    /*static public String compressIntoSerializedFC(byte[] inputBuf) throws IOException
    {
        return compressIntoSerializedFC (inputBuf, false);
    }*/


    /**
     Compresses a buffer using the GZIP algorithm and returns a serialized CFC
     containing the compressed data
     @param inputBuf The buffer to compress
     @returns The compressed data as a byte array.
     */
    /*static public String compressIntoSerializedFC(byte[] inputBuf, boolean bIsUTF) throws IOException
    {
        return compressIntoSerializedFC (inputBuf, inputBuf.length, bIsUTF);
    }*/
    

    /**
     Decompresses a buffer using the GZIP algorithm.
     @param inputBuf The buffer to decompress
     @returns The decompressed data as a byte array.
     */
    static public byte [] decompress (byte[] inputBuf) throws IOException
    {
        return decompress (inputBuf, inputBuf.length);
    }
    /**
     Compresses a buffer using the GZIP algorithm.
     @param inputBuf The buffer to compress
     @param bufLen The length of the buffer.
     @returns The compressed data as a byte array.
     */
   /* static public String compressIntoSerializedFC( byte[] inputBuf, int bufLen, boolean bIsUTF) throws IOException 
    {

        CasaFieldCollection fcCompressed = compressIntoFC(inputBuf, bufLen, bIsUTF );

        String strCompressed = fcCompressed.serialize ();

        return strCompressed;
    }*/

    /**
     Compresses a buffer using the GZIP algorithm.
     @param inputBuf The buffer to compress
     @param bufLen The length of the buffer.
     @returns The compressed data as a byte array.
     */
   /* static public CasaFieldCollection compressIntoFC( byte[] inputBuf, int bufLen, boolean bIsUTF) throws IOException 
    {
        byte [] compressedBuf = Compressor.compress (inputBuf);
        CasaFieldCollection fcCompressed = new CasaFieldCollection ();
        if ( bIsUTF )
            fcCompressed.setFieldBASE64 (FLD_COMPRESSED_UTF_MSG, compressedBuf);
        else
            fcCompressed.setFieldBASE64 (FLD_COMPRESSED_MSG, compressedBuf);

        return fcCompressed;
    }*/

    /**
     Compresses a buffer using the GZIP algorithm.
     @param inputBuf The buffer to compress
     @param bufLen The length of the buffer.
     @returns The compressed data as a byte array.
     */
    /*static public String compressIntoSerializedFC( byte[] inputBuf, int bufLen) throws IOException 
    {
        return compressIntoSerializedFC( inputBuf, bufLen, false );
    }*/
    /**
     Compresses a buffer using the GZIP algorithm.
     @param inputBuf The buffer to compress
     @param bufLen The length of the buffer.
     @returns The compressed data as a byte array.
     */
    static public byte [] compress (byte[] inputBuf, int bufLen) throws IOException 
    {
        ByteArrayOutputStream baStream = new  ByteArrayOutputStream (8192);
        DeflaterOutputStream output = new DeflaterOutputStream (baStream);
        output.write (inputBuf, 0, bufLen);
        output.close ();
		byte array[] = baStream.toByteArray ();
		baStream.close();
        return array;
    }

    /**
     Decompresses a buffer using the GZIP algorithm.
     @param inputBuf The buffer to decompress
     @param bufLen The length of the input buffer.
     @returns The decompressed data as a byte array.
     */
    static public byte [] decompress (byte[] inputBuf, int bufLen) throws IOException
    {
        ByteArrayInputStream baInputStream = new ByteArrayInputStream (inputBuf, 0, bufLen);
        InflaterInputStream inputStream  = new InflaterInputStream (baInputStream);
        
        ByteArrayOutputStream   outBuf = new ByteArrayOutputStream (32768);
        int                     nBytesRead = 0;
        byte                    tmpBuf[] = new byte [8192];
        
        try
        {
            while ((nBytesRead = inputStream.read (tmpBuf)) > 0)            
                outBuf.write (tmpBuf, 0, nBytesRead);           
            
        }
        catch (EOFException anEOFException)
        {
            //treat this as a regular EOF and let the out buf be returned
        }

        byte array[] = outBuf.toByteArray();
        baInputStream.close();
        inputStream.close();
        outBuf.flush();
        outBuf.close();        
		
        return array;
    }
}