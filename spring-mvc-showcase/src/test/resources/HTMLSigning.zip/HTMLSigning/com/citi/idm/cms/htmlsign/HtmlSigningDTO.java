package com.citi.idm.cms.htmlsign;

import java.io.Serializable;
import java.security.cert.X509Certificate;

public class HtmlSigningDTO implements Serializable {
	
	
	private byte[] signedData;
	private X509Certificate aCertificate;
	private String originalData;
	/**
	 * @return the aCertificate
	 */
	public X509Certificate getACertificate() {
		return aCertificate;
	}
	/**
	 * @param certificate the aCertificate to set
	 */
	public void setACertificate(X509Certificate certificate) {
		aCertificate = certificate;
	}
	/**
	 * @return the originalData
	 */
	public String getOriginalData() {
		return originalData;
	}
	/**
	 * @param originalData the originalData to set
	 */
	public void setOriginalData(String originalData) {
		this.originalData = originalData;
	}
	/**
	 * @return the signedData
	 */
	public byte[] getSignedData() {
		return signedData;
	}
	/**
	 * @param signedData the signedData to set
	 */
	public void setSignedData(byte[] signedData) {
		this.signedData = signedData;
	}
	
	

}
