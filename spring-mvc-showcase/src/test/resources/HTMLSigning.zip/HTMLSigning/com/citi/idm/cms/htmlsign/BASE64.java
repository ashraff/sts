
package com.citi.idm.cms.htmlsign;

/**
 * This class implements a BASE64 Character encoder as specified in RFC1521.
 * This RFC is part of the MIME specification as published by the Internet
 * Engineering Task Force (IETF). Unlike some other encoding schemes there
 * is nothing in this encoding that indicates
 * where a buffer starts or ends.
 *
 * This means that the encoded text will simply start with the first byte
 * of encoded text and end with the last byte of encoded text.
 *
 * @version	1.0, 10 Apr 1997
 * @author	Jonathan Trott
 */

public class BASE64 {


     /** This array maps the characters to their 6 bit values */
    private final static char pem_array[] = {
	//	 0   1	 2   3	 4   5	 6   7
		'A','B','C','D','E','F','G','H', // 0
		'I','J','K','L','M','N','O','P', // 1
		'Q','R','S','T','U','V','W','X', // 2
		'Y','Z','a','b','c','d','e','f', // 3
		'g','h','i','j','k','l','m','n', // 4
		'o','p','q','r','s','t','u','v', // 5
		'w','x','y','z','0','1','2','3', // 6
		'4','5','6','7','8','9','+','/'  // 7
	};

   /**
     * Encode bytes from the input buffer and return a String object.
     */
    public final static String encodeBuffer(String str)
	{
		int		len = str.length();
		byte [] inBuf = new byte[len];

		str.getBytes(0, len, inBuf, 0);
		return encodeBuffer(inBuf);
	}
   /**
     * Encode bytes from the input buffer and return a String object.
     */
    public final static String encodeBuffer(byte [] inBuff)
	{
	byte a, b, c;
	int	numBytes = inBuff.length;

	if (numBytes == 0)
		return "";

	byte outBuff [] = new byte [(((numBytes-1)/3)+1)<<2];

    /**
     * Take three bytes of input and encode it as 4
     * printable characters. Note that if the length in len is less
     * than three is encodes either one or two '=' signs to indicate
     * padding characters.
     */

		for (int pos = 0, len = 3, j = 0; j < numBytes; j+=3)
		{
			if ((j+3) > numBytes)
				len = numBytes - j;

			if (len == 3)
			{
				a = inBuff[j];
				b = inBuff[j+1];
				c = inBuff[j+2];
				outBuff [pos++] = (byte)pem_array[(a >>> 2) & 0x3F];
				outBuff [pos++] = (byte)pem_array[((a << 4) & 0x30) + ((b >>> 4) & 0xf)];
				outBuff [pos++] = (byte)pem_array[((b << 2) & 0x3c) + ((c >>> 6) & 0x3)];
				outBuff [pos++] = (byte)pem_array[c & 0x3F];
			} 
			else if (len == 2)
			{
				a = inBuff[j];
				b = inBuff[j+1];
				c = 0;
				outBuff [pos++] = (byte)pem_array[(a >>> 2) & 0x3F];
				outBuff [pos++] = (byte)pem_array[((a << 4) & 0x30) + ((b >>> 4) & 0xf)];
				outBuff [pos++] = (byte)pem_array[((b << 2) & 0x3c) + ((c >>> 6) & 0x3)];
				outBuff [pos++] = (byte)'=';
			}
			else
			{
				a = inBuff[j];
				b = 0;
				c = 0;
				outBuff [pos++] = (byte)pem_array[(a >>> 2) & 0x3F];
				outBuff [pos++] = (byte)pem_array[((a << 4) & 0x30) + ((b >>> 4) & 0xf)];
				outBuff [pos++] = (byte)'=';
				outBuff [pos++] = (byte)'=';
			}
		}

		return new String (outBuff);
    }

   /**
     * Decode bytes from a String object and return a byte array.
     */
    public final static byte [] decodeBuffer (String inString)
    {
		int  pos;
		char ch;
		byte a = 0, b = 0, c = 0, d = 0;

		int len = inString.length();
		char [] inBuff = new char [len];
		inString.getChars (0, len, inBuff, 0);

		int pad = 0;
		/* check for padding characters and adjust length */
		if (inBuff [len-1] == '=')
		{
			pad++;
			if (inBuff [len-2] == '=')
				pad++;
		}

		byte [] outBuff = new byte [((len >> 2) * 3) - pad];

		if (((len >> 2) << 2) == len) {
			//throw new RuntimeException ("BASE64Decoder: Bad input length");
                pos = 0;
		for (int j = 0, l = 3; j < len; j += 4)
		{
			for (int nFound = 0, i = 0; i < 64 && nFound != 4; i++)
			{
				ch = pem_array[i];
				if (inBuff [j] == ch)
				{
					a = (byte) i;
					nFound ++;
				}

				if (inBuff [j+1] == ch)
				{
					b = (byte) i;
					nFound ++;
				}

				if (inBuff [j+2] == ch)
				{
					c = (byte) i;
					nFound ++;
				}

				if (inBuff [j+3] == ch)
				{
					d = (byte) i;
					nFound ++;
				}
			}

			if (j+4 == len)
				l -= pad;

			if (l == 3)
			{
				outBuff [pos++] = (byte) (((a << 2) & 0xfc) | ((b >>> 4) & 3));
				outBuff [pos++] = (byte) (((b << 4) & 0xf0) | ((c >>> 2) & 0xf));
				outBuff [pos++] = (byte) (((c << 6) & 0xc0) | (d  & 0x3f));
			}
			else if (l == 2)
			{
				outBuff [pos++] = (byte) (((a << 2) & 0xfc) | ((b >>> 4) & 3));
				outBuff [pos++] = (byte) (((b << 4) & 0xf0) | ((c >>> 2) & 0xf));
			}
			else
			{
				outBuff [pos++] = (byte)(((a << 2) & 0xfc) | ((b >>> 4) & 3));
			}

		}
		}
		return outBuff;
    }

}
