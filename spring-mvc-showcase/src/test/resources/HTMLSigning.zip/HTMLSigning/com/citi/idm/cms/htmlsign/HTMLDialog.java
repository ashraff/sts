/***************************************************************
 *
 *   The use, disclosure, reproduction, modification, transfer,
 *   or transmittal of this work for any purpose in any form or
 *   by any means without the written permission of Citibank, N.A.
 *   is strictly prohibited.
 *
 *	 Author : Ashraff Ali wahab
 *   Copyright (c) 2007 Citibank, N.A.
 *   All rights reserved
 *
 *******************************************************************/
package com.citi.idm.cms.htmlsign;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.Signature;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.StringTokenizer;

import javax.swing.ImageIcon;
import javax.swing.JApplet;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import netscape.javascript.JSObject;



public class HTMLDialog extends JApplet 
{
	public static final String PROVIDER_CLASS_NAME = "sun.security.mscapi.SunMSCAPI";
	public static final String SUBMIT_BUTTON_NAME = getString("Submit");
	public static final String SIGN_BUTTON_NAME = getString("Sign");
	public static final String CANCEL_BUTTON_NAME = getString("Close");
	public static final String DUMMY_LIST = "DummyList";
	public static final String TITLE = getString("Title");
	public static final String SIGNED_BY = getString("I agree");
	public static final String COUNTERSIGNED_BY = getString("COUNTERSIGN_LABEL");
	public static final String SUBMIT_WITHOUT_SIGN_MESSAGE = getMessage("SUBMIT_WITHOUT_SIGN_MESSAGE");
	public static final String SIGN_ERROR = getMessage("SIGN_ERROR");
	public static final String MULTIPLE_SIGN_MESSAGE = getMessage("MULTIPLE_SIGN_MESSAGE");
	public static final String NO_VALID_CERTIFICATE = getMessage("NO_VALID_CERTIFICATE");
	public static final String CANCEL_WARNING = getMessage("CANCEL_WARNING");
	private static final SimpleDateFormat aHTMLDateTime = new SimpleDateFormat(IDMConstants.HTML_DATE_TIME_FORMAT);
	private static final String FONT_NAME = "Arial Unicode MS";
	private static final long serialVersionUID = -2140566910111834398L;
	private static final Color SIGNATURE_DISPLAY_COLOR = new Color(64,64,100);
	private static final String STR_SPACE = " "; 
	private static final String STR_EMPTY = "";
	
	//private static final ImageIcon ICON_SIGNATURE = new ImageIcon(GetImage.getImage("html_check_mark.jpg"));
	
	private byte[] signedData = null;
	private X509Certificate aCertificate = null;
	private String mHTML = STR_EMPTY;
	
	private JButton m_SignButton = null;
	private JButton m_SubmitButton = null;
	
	private boolean m_isEdittable = false;
	private JPanel m_SignaturePanel = null;
	private String sSignDateTime = null;

	
	public void init() 
	{
	    try {
	    	this.mHTML = getParameter("TESTSIGNHTML");
	    	
	        javax.swing.SwingUtilities.invokeAndWait(new Runnable() {
	            public void run() {
	            	createHTMLDialog();
	            }
	        });
	                   
	         
	    } catch (Exception e) {
	        System.err.println("createGUI didn't successfully complete");
	    }
	}

	/**
	 * 
	 * @param frame
	 * @param formattedHTML
	 * @param isEdittable
	 * @throws UserDefinedException
	 */
	public void createHTMLDialog()
	{
		try
		{
			System.out.println("createHTMLDialog");
			this.setSize(new Dimension(950, 650));
			this.m_isEdittable = true;
			//
			
			if(this.mHTML.length()==0)
				this.mHTML = "<html><body>" +
					"<font size=12><B>SAFE End-User Subscriber Agreement</B></font><br>I. " +
					"This SAFE End-User Subscriber Agreement (the Agreement) is a binding, contractual agreement between me and SAFE-BioPharma,<br>Association (SAFE). " +
					"I am applying for a digital identity, in the form of a digital credential and associated hardware (Credential), from SAFE<br>that " +
					"will enable me to create and use Digital Signatures in electronic form. I agree not to challenge the legal effect, validity, " +
					"or enforceability of<br>any electronic record or electronic signature (including any Digital Signature) on the grounds that " +
					"it is in digital rather than paper form.<br>" +		
					"Authorized Signer<br>c. upon expiration or notice of revocation of my Certificate, " +
					"I shall no longer<br>use the Certificate for any purposed. upon receipt by SAFE of any notice<br>from me " +
					"regarding erroneous information in my Certificate, SAFE may<br>revoke my Certificate and issue a corrected " +
					"Certificate;<br>e. if needing to rely upon a SAFE-signed electronic record, I shall: (i) verify<br>the accompanying " +
					"Digital Signature; and (ii) reject the such record if the<br>Digital Signature is invalid; and<br>f. any device with " +
					"which I will interact to apply a SAFE signature has<br>appropriate security controls installed and activated, and that " +
					"the latest<br>updates are applied.<br>" +
					"3. I WARRANT TO SAFE AND ANYONE WHO RELIES ON MY<br>CERTIFICATE THAT:<br>a. all " +
					"the information I provided to SAFE for use in my Certificate is<br>accurate;<br>b. no information I provided to SAFE " +
					"for use in my Certificate (including my<br>e-mail address) infringes the intellectual property rights of any third " +
					"parties;<br>c. the Certificate information I provided has not been and will not be used<br>for any unlawful purpose;<br>d." +
					/*" I have been and will remain the only person (i) able to access my Private<br>Key or (ii) possessing any access information " +
					"or hardware mechanism<br>protecting my Private Key; and<br>e. I am using my Credential exclusively for authorized and legal " +
					"purposes<br>consistent with this Agreement.<br>III. I AGREE THAT I HAVE READ, UNDERSTOOD, " +
					"AND<br>AGREED TO ALL OF THE FOLLOWING:<br>1. I WILL:<br>a. take all reasonable measures to protect the Credential," +
					"<br>Private Key, and any activation data (e.g., PIN), and<br>immediately report the loss or destruction of the Credential;<br>b. " +
					"review my information contained in the Certificate before<br>using it and promptly notify SAFE of any errors;<br>c. neither copy my Private" +
					" Key, nor allow it to be used by<br>another person;<br>d. immediately request revocation of my Certificate if: (i)<br>any data used " +
					"to access my Private Key, the token<br>containing my Private Key, or my Private Key are insecure in<br>any way; (ii) any of the information" +
					" contained in the<br>Certificate, or my identification and authentication information<br>has been changed; and<br>e. review, at least " +
					"annually, all of my obligations under this<br>Agreement.<br>2. I UNDERSTAND AND AGREE THAT:<br>a. my electronic Digital Signature will " +
					"have the same value,<br>force and effect as my written signature;<br>b. when my association with SAFE ends, my Certificate<br>may be " +
					"revoked and my ability and authorization to use my<br>Private Key for any new Digital Signatures will cease;<br>II. The Credentials " +
					"provided under this Agreement are issued within the SAFE system to facilitate SAFE Digital Signatures. Terms and words<br>used in this " +*/
					"<br>Agreement are consistent with the meanings as defined in the SAFE Certificate Policy (the CP), which can be found at" +
					"<br>http://www.safe-biopharma.org/index.php?option=com_content&task=view&id=196&Itemid=296.<br></body></html>";
			
			JEditorPane editor = new JEditorPane(IDMConstants.HTML_CONTENT_TYPE, this.mHTML);
			
			editor.setEditable(false);
			editor.setBorder(null);
			editor.setMargin(null);
			editor.setOpaque(false);
			
	
	
			Font paneFont = new Font(FONT_NAME, Font.PLAIN, 8);
			editor.setFont(paneFont);
			
			JScrollPane scrollPane = new JScrollPane();
			scrollPane.getViewport().add(editor);
			scrollPane.setPreferredSize(new Dimension(950,500));
	
			JPanel aInnerPanel = new JPanel();
			aInnerPanel.setLayout(new GridBagLayout());
			aInnerPanel.setSize(new Dimension(950,500));
				
			GridBagConstraints aLayoutConstraint = new GridBagConstraints();
				
			// common constraints
			aLayoutConstraint.fill = GridBagConstraints.BOTH;
			aLayoutConstraint.gridx = 0;
			aLayoutConstraint.gridwidth = 2;
			aLayoutConstraint.weightx = 1.0;
			aLayoutConstraint.gridheight = 1;
			
			// constraints for the HTML window
			aLayoutConstraint.weighty = 1.0;
			aLayoutConstraint.gridy = 0;
			aInnerPanel.add(scrollPane, aLayoutConstraint);
			
			// constraints for the counter signature
			aLayoutConstraint.weighty = 0.0;
			aLayoutConstraint.gridy = 1;
			
			if(m_isEdittable)
			{
				m_SignaturePanel = getSignaturePanel(SIGNED_BY,STR_EMPTY,STR_EMPTY);
				aInnerPanel.add(m_SignaturePanel,aLayoutConstraint);
			}

			this.getContentPane().add(aInnerPanel);
			((JPanel) m_SignaturePanel.getComponent(1)).setVisible(false);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	private JButton getSignButton() 
	{
		m_SignButton = new JButton(SIGN_BUTTON_NAME);
		m_SignButton.setToolTipText(SIGN_BUTTON_NAME);
		m_SignButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				signButtonClicked();
			}
		    });
		m_SignButton.setName("SIGN" + System.currentTimeMillis());
		return m_SignButton;
	}

	private JButton getSubmitButton() 
	{
		m_SubmitButton = new JButton(SUBMIT_BUTTON_NAME);
		m_SubmitButton.setToolTipText(SUBMIT_BUTTON_NAME);
		m_SubmitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				submitButtonClicked();
			}
		    });
		m_SubmitButton.setName("SUBMIT" + System.currentTimeMillis());
		m_SubmitButton.setEnabled(false);
		return m_SubmitButton;
	}
	

	private void signButtonClicked() {

		try {
			signedData = signData();
			this.m_SubmitButton.setEnabled(true);

			if (signedData == null) {
				this.m_SubmitButton.setEnabled(false);
				this.m_SignButton.setEnabled(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
			signedData = null;
			sSignDateTime = null;
		}
	}

	private void submitButtonClicked() 
	{
		try 
		{
	        JSObject win = JSObject.getWindow(this);
            JSObject doc = (JSObject) win.getMember("document");
            JSObject form = (JSObject) doc.getMember("sForm");
	        JSObject cert = (JSObject) form.getMember("txtCert");
	        JSObject enc = (JSObject) form.getMember("txtEncrypt");
	        JSObject orig = (JSObject) form.getMember("txtOrig");
	        
	        cert.setMember("value", signedData);
	        enc.setMember("value", aCertificate);
	        orig.setMember("value", mHTML);
	        
	        win.call("doSubmit", null);   

			//SSLPost.doPost(signedData, aCertificate,m_url,mHTML);
			//this.m_SubmitButton.setEnabled(false);
			//this.m_SignButton.setEnabled(false);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	/**
	 * 
	 * @return bytestream to Signed Data
	 * @throws Exception
	 */
	private byte[] signData() throws Exception {
		byte[] signedInfo = null;
		KeyStore ks = KeyStore.getInstance("Windows-MY", getProvider());
		ks.load(null, null);

		
		String aliasName = null;
		java.util.Enumeration en = ks.aliases();
		boolean certificateFound = false;
		DN aSubjectDN = null;
		while (en.hasMoreElements()) {
			String storedAliasKey = (String) en.nextElement();
			aCertificate = (X509Certificate) ks.getCertificate(storedAliasKey);
			aSubjectDN = new DN(aCertificate.getSubjectDN().getName());
			aliasName = storedAliasKey;
			certificateFound = true;
			break;
		}
		if (certificateFound) {
			PrivateKey privateKey = (PrivateKey) ks.getKey(aliasName, null);

			Signature dsa = Signature.getInstance(IDMConstants.SIGNING_ALGORITHM, getProvider());
			dsa.initSign(privateKey);
			dsa.update(mHTML.getBytes());
			signedInfo = dsa.sign();
			
			((JPanel) m_SignaturePanel.getComponent(1)).setVisible(true);
			((JLabel) m_SignaturePanel.getComponent(2)).setText(aSubjectDN.getCommonName());
			((JLabel) m_SignaturePanel.getComponent(2)).revalidate();
			sSignDateTime = getFormattedDateTimeForSignatureLine();
			((JTextArea) m_SignaturePanel.getComponent(3)).setText(getSignatureLine(aSubjectDN.getCommonName(),aSubjectDN.toString(), sSignDateTime));
			m_SignaturePanel.invalidate();
		}
		return signedInfo;
	}

	/** Reflection creates instance of Provider for Sun MS CAPI */
	private static Provider getProvider() throws Exception {

		Class aProviderClass;
		Object aProviderObj;
		aProviderClass = Class.forName(PROVIDER_CLASS_NAME);
		aProviderObj = aProviderClass.newInstance();
		return (Provider) aProviderObj;

	}

	/**
	 * 
	 * @param id
	 * @return
	 */
	private static String getMessage(String id) {
		return id;//LMFString.getString(IDMConstants.RESOURCE_BUNLDE_NAME,IDMConstants.RESOURCE_MSG_PREFIX + id);
	}

	/**
	 * Used to Build Label from resource bundle
	 */
	private static String getString(String id) {
		return id;//LMFString.getString(IDMConstants.RESOURCE_BUNLDE_NAME,IDMConstants.RESOURCE_MSG_PREFIX + id);
	}
	
	private static String getSignatureLine(String sCommonName, String sDN, String sDateTime){
		try {
			return "Digitally Signed by "+sCommonName+" , DN: "+sDN+" , Date: "+sDateTime;
		} catch (Exception e) {
			e.printStackTrace();
			return(null);
		}
	}
	
	private static String getFormattedDateTimeForSignatureLine(){
		return(aHTMLDateTime.format(new Date(System.currentTimeMillis())));
	}

	/*private JLabel getOperationDescComponent(String operation){
		JLabel aSignLabel = new JLabel(new StringBuffer(operation).append(SIGNATURE_SEPERATOR).toString());
		aSignLabel.setForeground(SIGNATURE_DISPLAY_COLOR);
		aSignLabel.setPreferredSize(new Dimension(120,25));
		aSignLabel.setHorizontalAlignment(JLabel.RIGHT);		
		return(aSignLabel);
	}*/
	
	private JPanel getSignatureIconComponent(){
		JPanel aSignerImagePanel = new JPanel();
		JLabel aSignerImageLbl = new JLabel(new ImageIcon("\\logo.jpg"));
		aSignerImagePanel.add(aSignerImageLbl);
		return(aSignerImagePanel);
	}
	private JLabel getSubjectNameComponent(String subjectName){
		JLabel aSignerNameLbl = new JLabel(subjectName);
		aSignerNameLbl.setFont(new Font(FONT_NAME,Font.PLAIN,24));
		aSignerNameLbl.setForeground(SIGNATURE_DISPLAY_COLOR);
		return(aSignerNameLbl);
	}
	
	private JTextArea getSubjectDNComponent(JPanel aSignaturePanel, String DN){
		JTextArea  aArea = new JTextArea(2,60);
		aArea.setFont(new Font(FONT_NAME,Font.PLAIN,11));
		aArea.setForeground(SIGNATURE_DISPLAY_COLOR);
		aArea.setDisabledTextColor(SIGNATURE_DISPLAY_COLOR);
		aArea.setAutoscrolls(false);
		aArea.setBackground(aSignaturePanel.getBackground());
		aArea.setFocusable(false);
		aArea.setEnabled(false);
		aArea.setLineWrap(true);
		aArea.setText(DN);
		return(aArea);
	}
	
	private JPanel getSignaturePanel(String operation, String subjectName, String DN){
		JPanel aSignaturePanel = new JPanel();
		aSignaturePanel.setLayout(new FlowLayout(FlowLayout.LEADING));
		
		aSignaturePanel.add(getSignButton());
		//aSignaturePanel.add(getOperationDescComponent(operation));
		aSignaturePanel.add(getSignatureIconComponent());
		aSignaturePanel.add(getSubjectNameComponent(subjectName));
		aSignaturePanel.add(getSubjectDNComponent(aSignaturePanel, DN));
		aSignaturePanel.add(getSubmitButton());
		return(aSignaturePanel);
	}
	
	
	private class DN {
		private static final String DN_NVPAIR_SEPARATOR = ",";
		private static final String DN_RNDS_SEPARATOR = "=";
		
		public static final String DN_COMMON_NAME = "CN";
		public static final String DN_ORG_UNIT = "OU";
		public static final String DN_ORGANIZATION = "O";
		public static final String DN_COUNTRY = "C";
		public static final String DN_EMAIL_ADDRESS = "EMAILADDRESS";
		
		private String m_CommonName = null;
		private String m_OrgUnit = null;
		private String m_Organization = null;
		private String m_Country = null;
		private String m_EmailAddress = null;
		
		public DN(String sDN) throws Exception{
			StringTokenizer aDnTokenizer = new StringTokenizer(sDN,DN_NVPAIR_SEPARATOR);
			while(aDnTokenizer.hasMoreTokens()){
				StringTokenizer aTokenizer = new StringTokenizer((String)aDnTokenizer.nextToken(),DN_RNDS_SEPARATOR);
				String sToken = aTokenizer.nextToken().replaceAll(STR_SPACE, STR_EMPTY);
				if(sToken.equalsIgnoreCase(DN_COMMON_NAME))
					m_CommonName = aTokenizer.nextToken();
				else if(sToken.equalsIgnoreCase(DN_ORG_UNIT))
					m_OrgUnit = aTokenizer.nextToken();
				if(sToken.equalsIgnoreCase(DN_ORGANIZATION))
					m_Organization = aTokenizer.nextToken();
				if(sToken.equalsIgnoreCase(DN_COUNTRY))
					m_Country = aTokenizer.nextToken();
				if(sToken.equalsIgnoreCase(DN_EMAIL_ADDRESS))
					m_EmailAddress = aTokenizer.nextToken();
				
			}
		}
		
		public String getCommonName(){
			return(m_CommonName);
		}
		
		public String getOrgUnit(){
			return(m_OrgUnit);
		}

		public String getOrganization(){
			return(m_Organization);
		}

		public String getCountry(){
			return(m_Country);
		}

		public String getEmailAddress(){
			return(m_EmailAddress);
		}
		
		private boolean matchComponent(String sValue, String sInputValue, boolean bStripSpaces){
			if(sValue == null || sInputValue == null)
				return(false);
			
			String sSource = (bStripSpaces?sValue.replaceAll(STR_SPACE, STR_EMPTY):sValue);
			String sTarget = (bStripSpaces?sInputValue.replaceAll(STR_SPACE, STR_EMPTY):sInputValue);
			if(sSource.equalsIgnoreCase(sTarget))
				return(true);
			else
				return(false);
		}
		
		public boolean isSameAs(DN aDN, boolean matchOnlyMandatoryFields, boolean bStripSpaces){
			if(matchOnlyMandatoryFields){
				if(!matchComponent(m_CommonName, aDN.getCommonName(), bStripSpaces))
					return(false);
				if(!matchComponent(m_OrgUnit, aDN.getOrgUnit(), bStripSpaces))
					return(false);
				if(!matchComponent(m_Organization, aDN.getOrganization(), bStripSpaces))
					return(false);
				if(!matchComponent(m_Country, aDN.getCountry(), bStripSpaces))
					return(false);
				return(true);
			}
			if(!matchComponent(m_EmailAddress, aDN.getEmailAddress(), bStripSpaces))
				return(false);
			return(true);
		}
		
		private void appendComponent(StringBuffer aBuffer, String sComponent, String sValue){
			if(sValue != null && !sValue.equals(STR_EMPTY)){
				if(aBuffer.length() > 0)
					aBuffer.append(DN_NVPAIR_SEPARATOR).append(STR_SPACE);
				aBuffer.append(sComponent).append(DN_RNDS_SEPARATOR).append(sValue);
			}
		}

		public String toString(boolean bShowAllFields){
			StringBuffer aStringDN = new StringBuffer();

			appendComponent(aStringDN, DN_COUNTRY, m_Country);
			appendComponent(aStringDN, DN_ORGANIZATION, m_Organization);
			appendComponent(aStringDN, DN_ORG_UNIT, m_OrgUnit);
			appendComponent(aStringDN, DN_COMMON_NAME, m_CommonName);
			if(bShowAllFields){
				appendComponent(aStringDN, DN_EMAIL_ADDRESS, m_EmailAddress);
			}
			return aStringDN.toString();
		}
		
		public String toString(){
			return toString(false);
		}
	}


}
