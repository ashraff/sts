CLONE CREATION:
--------------
1. Copy the was-scripts-1.0-bin.tar.gz to the staging location in SERVER where Deployment Manager is running. The copied directory is called <COPIED_DIR> in the rest of the steps.

2. Login to the Server , Change directory where the tar file is copied. Extract the tar file using the below command. 
	gunzip -d was-scripts-1.0-bin.tar.gz
	tar -xvf was-scripts-1.0-bin.tar

3. Change directory using the below command.
	cd <COPIED_DIR>/entitlement/gtsadmin/config/
4. Edit the configure.properties file to update the was_home and tools_home to point to the WAS installation direcory and the gtsadmin directory and save it.
     E.g.,
	export was_home=/export/opt/WebSphere/7.0/AppServer
	export tools_home=<COPIED_DIR>/entitlement/gtsadmin/

5. Update the following application_<ENV>.xml in <COPIED_DIR>/entitlement/gtsadmin/data folder. For BE it will be SIT1 , SIT2, SIT4, SIT5, UAT1, PTE or PROD.
	TOOLS_HOME to point to the <COPIED_DIR>/entitlement/gtsadmin folder.
	
6. Change directory using the below command and change the permission of transform.sh to execute.
	cd ../bin
	chmod +x transform.sh


7. Run the below command and wait for the command to complete. <ENV> will be the name of environment you are working on. For BE it will be SIT1 , SIT2, SIT4, SIT5, UAT1, PTE or PROD.

	./transform.sh ../data/application_<ENV>.xml

8. Navigate to Websphere Deployment manager bin directory (usually /export/opt/WebSphere/7.0/AppServer) and run the below command. <DATE> should be replaced by date in the format MM_DD_YYYY
./backupConfig.sh WebSphereConfig_<DATE>.zip -nostop

9. Navigate to <COPIED_DIR>/entitlement/gtsadmin/bin directory and change the permission of configureCell.sh to execute.
	chmod +x configureCell.sh

10. Run the below command and wait to complete.

	./configureCell.sh <admin_console_user> <admin_console_password>


ROLLBACK:
---------
 Navigate to Websphere Deployment manager bin directory (usually /export/opt/WebSphere/7.0/AppServer) and run the below command. <DATE> should be replaced by date in the format MM_DD_YYYY which you backuped up in STEP 8.
	./restoreConfig.sh WebSphereConfig_<DATE>.zip -nostop